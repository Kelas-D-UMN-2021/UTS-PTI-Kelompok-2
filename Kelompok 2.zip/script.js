var slider_img = document.querySelector('.slider-img');
var images = ['a.png', 'b.png', 'c.png', 'd.png'];
var text = ['']
var i = 0;
var imagesMakan = ['amakan.gif', 'bmakan.gif', 'cmakan.gif', 'dmakan.gif'];
var imagesTidur = ['atidur.gif', 'btidur.gif', 'ctidur.gif', 'dtidur.gif'];
var imagesMain = ['amain.gif', 'bmain.gif', 'cmain.gif', 'dmain.gif'];
var imagesBelajar = ['abelajar.gif', 'bbelajar.gif', 'cbelajar.gif', 'dbelajar.gif'];
function prev(){
    if(i <= 0) i = images.length;	
    i--;
    return setImg();			 
}

function next(){
    if(i >= images.length-1) i = -1;
    i++;
    return setImg();			 
}

function setImg(){
    return slider_img.setAttribute('src', "images/"+images[i]);
}


$(document).ready(function(){
    
    d = new Date();
    jam = d.getHours();
    menit = d.getMinutes();
    

    setInterval(function () {
        if (menit < 10 && jam >= 10) {
            $("#jam").empty().append('<h3>' + jam + ':0' + menit + '</h3>');
        }
        else if (menit >= 10 && jam < 10) {
            $("#jam").empty().append('<h3>' + '0' + jam + ':' + menit + '</h3>');
        }
        else if(jam < 10 && menit < 10){
            $("#jam").empty().append('<h3>' + '0' + jam + ':0' + menit + '</h3>');
        }
        else{
            $("#jam").empty().append('<h3>' + jam + ':' + menit + '</h3>');
        }

        if (menit < 59) {
            menit += 1;
        }
        else{
            if (jam < 23) {
                jam++;
            }
            else{
                jam = 0;
            }
            menit = 0;
        }

        $("#play").click(function(){
            nama = $("#playername").val();
        })

        if (jam > 0 && jam < 12) {
            salam = "Good morning, ";
            salam_el = '<h3 class="text-center">' + salam + nama + '</h3>';
            if (nama != "") {
                $("#greeting").empty().append(salam_el);
            }

        }
        if (jam >= 12 && jam < 18) {
            salam = "Good afternoon, ";
            salam_el = '<h3 class="text-center">' + salam + nama + '</h3>';
            if (nama != "") {
                $("#greeting").empty().append(salam_el);
            }
        }
        if (jam >= 18 && jam < 24) {
            salam = "Good evening, ";
            salam_el = '<h3 class="text-center">' + salam + nama + '</h3>';
            if (nama != "") {
                $("#greeting").empty().append(salam_el);
            }
        }
    }, 500);
});




function startgame(){

    $("#home").hide();
    $("#gameplay").fadeIn();
    $("#karakter").attr({
        "src" : "images/"+images[i],
    });

    
    var makanProgressBar = document.getElementById('p1');
    setInterval(function() {
        if(makanProgressBar.value < 10){
            var warnstatusmakan = '<h6 class="text-center">You have to eat to continue the activity...</h6>';
            $("#warningmakan").empty().append(warnstatusmakan);
        }
        else{
            $("#warningmakan").empty(warnstatusmakan);
        }
        makanProgressBar.value -= 10;
        if(makanProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemakan").fadeIn();
        }
    }, 15000);  
    var makanButton = document.getElementById('tmakan');

    var makanProgressBar = document.getElementById('p1');
    setInterval(function() {
        if(makanProgressBar.value < 10){
            var warnstatusmakan = '<h6 class="text-center">You have to eat to continue the activity...</h6>';
            $("#warningmakan").empty().append(warnstatusmakan);
        }
        else{
            $("#warningmakan").empty(warnstatusmakan);
        }
    }, 1000);  
    var makanButton = document.getElementById('tmakan');

    var tidurProgressBar = document.getElementById('p2');
    setInterval(function() {
        if(tidurProgressBar.value < 10){
            var warnstatustidur = '<h6 class="text-center">You need sleep to rest yourself...</h6>';
            $("#warningtidur").empty().append(warnstatustidur);
        }
        else{
            $("#warningtidur").empty(warnstatustidur);
        }
        tidurProgressBar.value -= 10;
        if(tidurProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegametidur").fadeIn();
        }
    }, 15000);
    var tidurButton = document.getElementById('ttidur');

    var tidurProgressBar = document.getElementById('p2');
    setInterval(function() {
        if(tidurProgressBar.value < 10){
            var warnstatustidur = '<h6 class="text-center">You need sleep to rest yourself...</h6>';
            $("#warningtidur").empty().append(warnstatustidur);
        }
        else{
            $("#warningtidur").empty(warnstatustidur);
        }
    }, 1000);
    var tidurButton = document.getElementById('ttidur');

    var mainProgressBar = document.getElementById('p3');
    setInterval(function() {
        if(mainProgressBar.value < 10){
            var warnstatusmain = '<h6 class="text-center">Your life is too boring, go play something...</h6>';
            $("#warningmain").empty().append(warnstatusmain);
        }
        else{
            $("#warningmain").empty(warnstatusmain);
        }
        mainProgressBar.value -= 10;
        if(mainProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemain").fadeIn();
        }
    }, 15000);
    var mainButton = document.getElementById('tmain');

    var mainProgressBar = document.getElementById('p3');
    setInterval(function() {
        if(mainProgressBar.value < 10){
            var warnstatusmain = '<h6 class="text-center">Your life is too boring, go play something...</h6>';
            $("#warningmain").empty().append(warnstatusmain);
        }
        else{
            $("#warningmain").empty(warnstatusmain);
        }
    }, 1000);
    var mainButton = document.getElementById('tmain');

    var belajarProgressBar = document.getElementById('p4');
    setInterval(function() {
        if(belajarProgressBar.value < 10){
            var warnstatusbelajar = '<h6 class="text-center">Your learning experience is low, go study now...</h6>';
            $("#warningbelajar").empty().append(warnstatusbelajar);
        }
        else{
            $("#warningbelajar").empty(warnstatusbelajar);
        }
        belajarProgressBar.value -= 10;
        if(belajarProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamebelajar").fadeIn();
        }
    }, 15000);
    var belajarButton = document.getElementById('tbelajar');

    var belajarProgressBar = document.getElementById('p4');
    setInterval(function() {
        if(belajarProgressBar.value < 10){
            var warnstatusbelajar = '<h6 class="text-center">Your learning experience is low, go study now...</h6>';
            $("#warningbelajar").empty().append(warnstatusbelajar);
        }
        else{
            $("#warningbelajar").empty(warnstatusbelajar);
        }
    }, 5000);
    var belajarButton = document.getElementById('tbelajar');

    

    makanButton.addEventListener('click', function(event) {
        event.preventDefault();
        $("#karakter").attr({
            "src" : "images/"+imagesMakan[i],
        });
        makanProgressBar.value += 8;
        tidurProgressBar.value -= 3;
        mainProgressBar.value -= 2;
        belajarProgressBar.value -= 1;
        if(tidurProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegametidur").fadeIn();
        }
        if(mainProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemain").fadeIn();
        }
        if(belajarProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamebelajar").fadeIn();
        }
    });

    tidurButton.addEventListener('click', function(event) {
        event.preventDefault();
        $("#karakter").attr({
            "src" : "images/"+imagesTidur[i],
        });
        tidurProgressBar.value += 8;
        mainProgressBar.value -= 3;
        belajarProgressBar.value -= 2;
        makanProgressBar.value -= 1;
        if(makanProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemakan").fadeIn();
        }
        if(mainProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemain").fadeIn();
        }
        if(belajarProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamebelajar").fadeIn();
        }
    });

    mainButton.addEventListener('click', function(event) {
        event.preventDefault();
        $("#karakter").attr({
            "src" : "images/"+imagesMain[i],
        });
        mainProgressBar.value += 8;
        belajarProgressBar.value -= 3;
        makanProgressBar.value -= 2;
        tidurProgressBar.value -= 1;
        if(makanProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemakan").fadeIn();
        }
        if(tidurProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegametidur").fadeIn();
        }
        if(belajarProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamebelajar").fadeIn();
        }
    });

    
    var j = 2;
    belajarButton.addEventListener('click', function(event) {
        event.preventDefault();
        $("#karakter").attr({
            "src" : "images/"+imagesBelajar[i],
        });
        belajarProgressBar.value += 8;
        makanProgressBar.value -= 3;
        tidurProgressBar.value -= 2;
        mainProgressBar.value -= 1;
        var acongrats = '<h5 class="text-center ">Congratulation on your semester!!</h5>';
        if(belajarProgressBar.value == 100){
        $("#semester").children().text("Semester " + j);
        j++; 
        belajarProgressBar.value = 20;
        $("#congrats").empty().append(acongrats);
        }
        else{
            $("#congrats").empty(acongrats);
        }
        if(j == 8){
            $("#gameplay").hide();
            $("#endgame").fadeIn();
        }
        if(makanProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemakan").fadeIn();
        }
        if(tidurProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegametidur").fadeIn();
        }
        if(mainProgressBar.value == 0){
            $("#gameplay").hide();
            $("#losegamemain").fadeIn();
        }
    });
}

$(document).ready(function(){
    $("#gameplay").hide();
    $("#endgame").hide();
    $("#losegamemakan").hide();
    $("#losegametidur").hide();
    $("#losegamemain").hide();
    $("#losegamebelajar").hide();
});

