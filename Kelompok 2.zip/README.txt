Kelompok 2:
1. Azhar Bagaskara
00000062993
2. Zedro Deniro Mason
00000065951
3. Justin Su
00000063534
4. Muhammad Akbar M.P.
00000062913

Aturan Gameplay
1. Pemain memilih karakter terlebih dulu
2. Pemain meng-input nama
3. Tekan tombol start untuk memulai permainan
4. Status makan, tidur, dan main akan dimulai dari 50% sedangkan status belajar dimulai dari 20%
5. Permainan akan dimulai dari semester 1
6. Apabila value dari setiap status kurang dari 10% maka akan muncul warning
7. Jika status belajar sudah mencapai 100% maka status pemain akan naik ke semester selanjutnya
8. Sistem waktu dalam game ini adalah 1 menit dalam game sama dengan  0.5 detik pada dunia nyata
9. Jika pemain idle maka akan terjadi pengurangan poin pada status sebesar 10 poin
10. Pengurangan poin yang disebabkan karena idle jika tidak melakukan aktivitas selama 15 detik pada dunia nyata, yang berarti 30 menit dalam game
11. Setiap menekan tombol "EAT" maka akan terjadi penambahan point pada status makan sebesar 8 poin
    Pengurangan point status tidur sebesar 3
    Pengurangan point status main sebesar 2
    Pengurangan point status belajar sebesar 1
12. Setiap menekan tombol "SLEEP" maka akan terjadi penambahan point pada status tidur sebesar 8 poin
    Pengurangan point status main sebesar 3
    Pengurangan point status belajar sebesar 2
    Pengurangan point status makan sebesar 1
13. Setiap menekan tombol "PLAY" maka akan terjadi penambahan point pada status main sebesar 8 poin
    Pengurangan point status belajar sebesar 3
    Pengurangan point status makan sebesar 2
    Pengurangan point status tidur sebesar 1
14. Setiap menekan tombol "STUDY" maka akan terjadi penambahan point pada status belajar sebesar 8 poin
    Pengurangan point status makan sebesar 3
    Pengurangan point status tidur sebesar 2
    Pengurangan point status belajar sebesar 1
15. Terdapat fitur play musik sebagai sarana pendukung permainan yang otomatis memulai lagu,
    lagu ini akan looping ketika lagunya habis, player dapat mematikan lagu jika tidak diinginkan.
16. Apabila poin dari setiap status habis maka game akan selesai.